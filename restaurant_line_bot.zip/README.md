# LINE Restaurant Chatbot

## ฟีเจอร์
- ตอบคำถามอัตโนมัติ (เมนู, โปร, ที่อยู่, เวลาเปิดปิด, เบอร์โทร)
- รับจองโต๊ะ พร้อมสรุปการจอง
- Quick reply ให้ลูกค้าเลือกง่าย

## การติดตั้ง
1. ติดตั้ง Python 3.11+
2. สร้างไฟล์ `.env` จาก `.env.example`
3. ใส่ `CHANNEL_ACCESS_TOKEN` และ `CHANNEL_SECRET` จาก LINE Developers
4. รันเซิร์ฟเวอร์:
```bash
pip install -r requirements.txt
python app.py
```
